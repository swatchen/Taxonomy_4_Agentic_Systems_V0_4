[[def: Orchestrator]]

A synonym/title for the Non-Agent Workflow in the Architectural (Safety) Triad, emphasizing that it contains the execution logic: it interprets generated media and routes any resulting actions through Workspace actuators.
