[[def: Adversarial Generative Review]]

A high-assurance security process in which one or more adversarial Agentflows are contained within a Policy Engine’s Workflow to review the basis of capability requests. The Workflow only proceeds when a quorum of adversarial peers agrees the requested capability is appropriate for the current risk profile.
