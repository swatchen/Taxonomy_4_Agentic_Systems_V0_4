[[def: Legal interpretation]]

The taxonomy’s notion that only Non-Agent Workflows are allowed to interpret agent-produced media into executable actions (“the only legal interpretations of agent media”), making interpretation deterministic, reviewable, and certifiable.
