[[def: Forensic Workspace]]

A workspace operated for transparency and compliance verification, used by a trusted peer to host and inspect an Auditable Replica of another agent’s state.
