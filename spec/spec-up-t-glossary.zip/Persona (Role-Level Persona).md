[[def: Persona (Role-Level Persona)]]

The user-perceived continuity of behavior and perspective that emerges from an Agent Role’s persistent identity and memory, rather than from any individual Live Agent instance
