[[def: Bio-Augmented State]]

An extreme state of embeddedness where a Live Agent is coupled with a real-time stream of biological signals, such as neural firing patterns from a Brain-Computer Interface (BCI) or physiological stress levels from biometric monitors.
