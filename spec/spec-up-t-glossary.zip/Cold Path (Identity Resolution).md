[[def: Cold Path (Identity Resolution)]]

The high-friction, "heavy lift" phase of security involving rigorous cryptographic checks (such as resolving DIDs and verifying lattice-based signatures) to establish a secure session and verify the identity of a principal, workspace, or agentflow.
