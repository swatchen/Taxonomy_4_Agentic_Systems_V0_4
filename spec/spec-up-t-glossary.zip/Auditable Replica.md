[[def: Auditable Replica]]

A complete, cryptographically verifiable snapshot of a Digital Twin state provided to a Fully Trusted Peer and hosted in the peer’s Forensic Workspace for transparency, compliance verification, and inspection.
