[[def: Intelligent Capability Granting]]

A dynamic trust model that evaluates potentially risky agent-suggested actions or capability requests by using Workflows as a policy engine to synthesize identity resolution, AgentFacts intelligence, and Role-specific policies, and optionally, adversarial generative review, to determine the precise attenuation of authority to grant via a capability token.
