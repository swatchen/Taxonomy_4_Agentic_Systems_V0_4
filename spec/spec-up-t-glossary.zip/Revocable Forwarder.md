[[def: Revocable Forwarder]]

An OCAP pattern in which a capability token is wrapped in an indirection layer that allows the Workspace to revoke or disable the capability after issuance, providing a “kill switch” for active or delegated authority.
