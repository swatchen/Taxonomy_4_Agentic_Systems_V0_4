[[def: Tool Misuse]]

A threat class that emerges when tool boundaries are unclear and systems are dangerously coupled.
