[[def: Fiduciary Pair]]

A high-assurance embeddedness state in which a human and their Digital Twin are certified together as a fiduciary entity; requires secure workspaces and verifiable logs, and is explicitly disallowed for “unmanned AI” without an accountable human.
