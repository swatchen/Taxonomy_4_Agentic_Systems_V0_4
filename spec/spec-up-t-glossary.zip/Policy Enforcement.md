[[def: Policy Enforcement]]

Enforcement of governance rules at the system’s execution layer: the Workspace provides policy mechanisms and capability boundaries, while Non-Agent Workflows apply policy checks during interpretation (e.g., deciding whether a requested signing action is valid under policy), or are simply enough in structure to be obviously incapable of going against policy. (e.g. a Workflow that can only output whether to mute or unmute a microphone)
