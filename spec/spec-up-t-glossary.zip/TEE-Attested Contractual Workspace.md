[[def: TEE-Attested Contractual Workspace]]

An installed configuration combining (1) a Secure Enclave Workspace (TEE) that can be remotely attested and (2) a Contractual Workspace (e.g., smart contract constraints) that defines immutable validity and permitted signing surfaces.
