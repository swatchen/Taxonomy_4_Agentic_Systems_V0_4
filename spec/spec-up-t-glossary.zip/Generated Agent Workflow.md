[[def: Generated Agent Workflow]]

An Agent Workflow that is authored dynamically by a parent Workflow as data and then executed to create a Generated Sub-Agent. It is typically tightly coupled to the generating context and not independently reusable or certifiable. It should also be highly constrained due to unpredictability.
