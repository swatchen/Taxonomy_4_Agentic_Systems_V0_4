[[def: Distributed Discovery]]

The process by which a Workspace or Workload resolves decentralized identifiers (DIDs), retrieves associated AgentFacts Documents and credentials from a registry, and evaluates trustworthiness prior to interaction or capability granting.
