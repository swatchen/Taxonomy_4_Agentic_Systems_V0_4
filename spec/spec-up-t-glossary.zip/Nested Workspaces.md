[[def: Nested Workspaces]]

A hierarchical embedding pattern where subordinate live agents execute inside their own sandbox workspaces embedded within (and governed by) a Supervisor workspace.
