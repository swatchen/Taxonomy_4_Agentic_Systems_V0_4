[[def: Loaded Agent]]

A Base Agent \+ all the context for immediate task execution. These are for quick loading, reusable agent instantiations, and used for often repeated tasks. Any Agent instantiation, such as rewinding a Workload, or reinstantiating a paused Agent creates a Loaded Agent. The term no longer applies once the Agent changes state from the initially loaded one.
