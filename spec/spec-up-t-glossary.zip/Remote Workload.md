[[def: Remote Workload]]

A Workload executing in a different Workspace, device, or environment, while still belonging to the same local Workflow invocation chain.
