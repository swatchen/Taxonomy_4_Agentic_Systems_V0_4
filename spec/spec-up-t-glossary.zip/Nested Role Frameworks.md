[[def: Nested Role Frameworks]]

A Role Framework pattern where a Role’s sub-workspace contains a hierarchy of sub-workspaces corresponding to Nested Agent Roles. The parent Role’s Framework becomes a “framework-of-frameworks,” defining which nested roles exist and how they share/partition data/policies and coordinate.
