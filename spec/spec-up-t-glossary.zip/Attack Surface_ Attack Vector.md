[[def: Attack Surface/ Attack Vector]]

The expanding set of exploitable vulnerabilities that arises when boundaries between an agent’s reasoning core, tools, and data sources are ill-defined; in T4AS terms, a symptom of insufficient enforcement of the Architectural (Safety) Triad.
