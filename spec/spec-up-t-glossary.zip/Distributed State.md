[[def: Distributed State]]

A state property of collective/swarm systems where the “loaded state” is the aggregate of many units rather than a single localized context store.
