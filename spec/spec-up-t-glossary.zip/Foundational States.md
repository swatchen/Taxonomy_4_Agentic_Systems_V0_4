[[def: Foundational States]]

The genesis of the embeddedness spectrum, representing "inert" definitions such as code, weights, and schemas that exist as data at rest. These states possess no agency or execution state and serve as the templates from which active systems are instantiated.
