[[def: Collective Workspace]]

An environment in which the “physics” of execution is the network fabric and coordination protocol itself; certification targets the interaction protocol and swarm integrity rather than only individual members.
