[[def: Trust Inheritance]]

The property by which Generated Workflows and Generated Sub-Agents derive their trustworthiness from the parent Workflow, Workspace, and governing policies, rather than from independent certification or catalog entries.
