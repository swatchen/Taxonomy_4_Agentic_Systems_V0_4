[[def: Zero Ambient Authority]]

The security condition in which a component—especially a Live Agent—begins execution with no implicit permissions, capabilities, or access to resources, and can only act indirectly through explicitly granted and mediated capabilities.
