[[def: Hardware Guarantees]]

Assurance properties derived from the execution substrate (e.g., TEE memory encryption, attestation semantics, sensor/actuator constraints) that materially affect embeddedness risk and certification scope.
