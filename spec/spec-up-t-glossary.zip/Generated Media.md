[[def: Generated Media]]

The only allowed output of an Agent (Live): e.g., text, code, images (or other generative outputs), which must be interpreted by a Workflow before any action is taken in a Workspace.
