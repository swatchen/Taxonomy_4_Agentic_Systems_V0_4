[[def: Governance (Role-Level)]]

The attachment of policies, permissions, and constraints to an Agent Role rather than to individual Agents (Live), enabling consistent enforcement across many ephemeral agent instantiations without accumulating hidden authority.
