[[def: Professed Preferences]]

Curated, explicitly declared preferences and aspirational goals used to train/condition a public-facing Digital Twin that represents its owner externally without access to the user’s unvarnished private data.
