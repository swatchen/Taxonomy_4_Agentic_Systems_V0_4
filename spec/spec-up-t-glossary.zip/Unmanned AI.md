[[def: Unmanned AI]]

An AI system operating without an accountable human owner “in the loop,” explicitly disallowed from holding certain fiduciary states in this taxonomy’s governance framing.
