[[def: Meta-Agent]]

A supervisory agent that decomposes tasks and creates subordinate agents (often generated) to handle subtasks, forming a hierarchical embedding structure. Also called a Supervisor Agent
