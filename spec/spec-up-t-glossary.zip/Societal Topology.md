[[def: Societal Topology]]

The structure of relationships, trust pathways, registries, and governance mechanisms within which agentic systems negotiate identity, reputation, and authority; part of the embedding context beyond memory and hardware.
