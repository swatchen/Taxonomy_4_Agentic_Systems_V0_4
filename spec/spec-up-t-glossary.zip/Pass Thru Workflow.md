[[def: Pass Thru Workflow]]

A dangerously thin Non-Agent Workflow pattern that performs minimal interpretation/checking and effectively forwards agent outputs toward actuators, enabling boundary collapse even if the triad exists nominally.
