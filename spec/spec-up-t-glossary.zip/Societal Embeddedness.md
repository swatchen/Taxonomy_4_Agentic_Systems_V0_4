[[def: Societal Embeddedness]]

An embeddedness class describing Agent Roles operating as sovereign peers in a decentralized network, where trust negotiation is shaped by Societal Topology, reputation, economic alliances, and governance norms.
