[[def: Refined Model]]

A model produced by group-level refinement (aggregation \+ update) which contributors adopt,  enabling evolution without manual reconfiguration of every instance.
