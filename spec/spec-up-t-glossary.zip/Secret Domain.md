[[def: Secret Domain]]

The private, local-first domain in segregated architectures where the internal steward (virtual assistant role) has access to the user’s unvarnished digital life and true preferences, but is forbidden from directly interacting with the public Internet.
