[[def: Reinstantiation]]

The deliberate practice of creating a new Agent (new Workload executing an Agent Workflow) that reuses selected persistent context (typically from an Agent Role). The initial state of this reinstantiation is termed a Loaded Agent.
