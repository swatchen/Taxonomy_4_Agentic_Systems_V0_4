[[def: Paused Workload]]

A Workload whose execution has been suspended, retaining sufficient data to rebuild state such that it may resume at a later time, materially unchanged.
