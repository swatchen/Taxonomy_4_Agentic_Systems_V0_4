[[def: Delegation (Workflow Delegation)]]

The act by which a Workflow assigns part of its computation to another Workflow or Agent (Live), either by generating a new structure or calling an existing one. Delegation is a structural relationship, not an execution privilege.
