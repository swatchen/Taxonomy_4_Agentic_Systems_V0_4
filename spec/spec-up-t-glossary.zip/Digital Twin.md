[[def: Digital Twin]]

A network-facing, personally-owned representative Agent Role intended to act as a sovereign ambassador for a human principal using curated data and professed preferences, negotiating with other systems while remaining bounded by governance and workspace constraints.
