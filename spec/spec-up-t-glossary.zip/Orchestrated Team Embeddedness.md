[[def: Orchestrated Team Embeddedness]]

A multi-agent embedding pattern where specialized agents collaborate under an explicit, Process-Oriented Orchestrating Workflow (not emergent behavior)
