[[def: Shade Agents]]

A concrete installed configuration pattern combining Secure Enclave Workspace (TEE) embedding with Contractual Workspace constraints, yielding guarantees via remote attestation plus on-chain deterministic guardrails for what counts as a valid instance and what signing actions are permitted.
