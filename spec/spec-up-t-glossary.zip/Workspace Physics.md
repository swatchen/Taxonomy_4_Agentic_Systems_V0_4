[[def: Workspace Physics]]

A descriptive notion that the Workspace defines the effective “physics” of an Agent’s universe—what actions exist, what constraints apply, and what guarantees hold.
