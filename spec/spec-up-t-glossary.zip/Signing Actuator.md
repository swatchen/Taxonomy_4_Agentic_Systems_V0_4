[[def: Signing Actuator]]

** A Workspace-provided actuator used to perform cryptographic signing with protected keys, invoked only after a Non-Agent Workflow parses an Agent’s or other signing request and checks it against policy; it produces “an auditable record.”
