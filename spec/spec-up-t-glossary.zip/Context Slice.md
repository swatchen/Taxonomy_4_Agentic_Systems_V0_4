[[def: Context Slice]]

The task-scoped subset of an Agent Role’s stored history/documents injected into a Loaded Agent for a specific objective, chosen to prevent Context Rot and reduce hallucination.
