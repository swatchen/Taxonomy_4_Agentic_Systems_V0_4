[[def: Post-hoc Forensics]]

After-the-fact investigation enabled because every state change is mediated by the Workspace and logged into Workload Execution Records, allowing later inspection/replay across Workflows and Agent Roles.
