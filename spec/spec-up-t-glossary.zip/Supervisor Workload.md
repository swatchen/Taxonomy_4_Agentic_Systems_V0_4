[[def: Supervisor Workload]]

The Workload that performs the instantiation step for a Live Agent by injecting the context needed to create an Agent Workload capable of generating output (i.e., the non-agent execution context that “forms” the live agent).
