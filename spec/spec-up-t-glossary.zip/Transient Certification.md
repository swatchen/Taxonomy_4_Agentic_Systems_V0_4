[[def: Transient Certification]]

A requirement posture for mobile/transient embeddedness where the agent/workflow should be re-certified upon migration based on its current state and new workspace guarantees; trust may be downgraded when moving to weaker environments.
