[[def: Contractual Workspace]]

A deployed state where a Live Agent is embedded within a cryptographic or legal system, such as a smart contract or an OCAP framework, that strictly bounds its permissible actions.
