[[def: Remote (Execution) Attestation]]

A cryptographic proof produced by a Secure Enclave Workspace demonstrating to a remote party exactly what code/agentflow is running inside the enclave.
