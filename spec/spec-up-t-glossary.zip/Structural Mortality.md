[[def: Structural Mortality]]

An architectural property in which Live Agents are guaranteed to be short-lived and non-persistent, eliminating incentives for long-term power-seeking, deception, or state accumulation by ensuring that agents do not “survive” beyond a single task execution.
