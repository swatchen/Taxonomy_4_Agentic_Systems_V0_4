[[def: Verifiable Logs]]

Cryptographically verifiable logs required for high-assurance fiduciary states and installed certification, enabling proof of what actions occurred under which code identity and workspace guarantees.
