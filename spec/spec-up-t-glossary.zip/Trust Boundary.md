[[def: Trust Boundary]]

A boundary at which assumptions about authority, capability, or correctness stop and must be re-established explicitly. In T4AS, Workspace boundaries are primary trust boundaries; crossing them requires explicit trust mechanisms and auditability.
