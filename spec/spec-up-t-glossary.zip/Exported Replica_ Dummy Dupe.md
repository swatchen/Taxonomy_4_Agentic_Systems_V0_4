[[def: Exported Replica/ Dummy Dupe]]

A lightweight replica of an Agent Role, intentionally stripped of private data and designed for trustworthy runs in untrusted environments. Compiled, wrapped in encryption, and revocable via provenance/authorization mechanisms.
