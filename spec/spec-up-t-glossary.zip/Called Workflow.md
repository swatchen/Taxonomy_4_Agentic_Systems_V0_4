[[def: Called Workflow]]

A pre-existing, named Workflow definition that is invoked through a stable interface rather than generated dynamically. Called Workflows are independently managed, versioned, and often certified, and serve as reusable peers or dependencies in larger systems.
