[[def: Composite Workflow]]

A Workflow “that invokes other Workflows—deterministic, generative, or both—as part of its operation,” forming the basis for hierarchical or multi-stage processes (including orchestrators that coordinate multiple Agents (Live)).
