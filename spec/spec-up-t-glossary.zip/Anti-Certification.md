[[def: Anti-Certification]]

A classification indicating a state that must be detected and mitigated (rather than certified), because the configuration is adversarial or structurally unsafe (e.g., Adversarial Embedding, Unfiltered Agent Workspace).
