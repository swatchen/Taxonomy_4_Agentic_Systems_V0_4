[[def: Hot Path (Instant Authorization)]]

The high-frequency, low-latency phase of security where, once identity is established, the system uses tiny symmetric tokens (Macaroons) for nearly instant movement and execution.
