[[def: Network-Level Identity]]

The use of Decentralized Identifiers (DIDs) and Verifiable Credentials to establish identity, provenance, and trust across multiple Workspaces and administrative domains, without relying on centralized identity providers.
