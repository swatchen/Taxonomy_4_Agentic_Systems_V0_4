[[def: Prophylactic Sandbox]]

A characterization of Ephemeral Workspace creation/destruction used to preempt persistence and reduce attack surface; the sandbox is “nuked” after output capture.
