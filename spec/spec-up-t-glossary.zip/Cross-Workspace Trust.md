[[def: Cross-Workspace Trust]]

A formally established trust relationship between Workspaces, grounded in explicit mechanisms (e.g., cryptographic identity, verifiable credentials, capability tokens, audit trails) rather than assumption. In T4AS, no Workspace is trusted by default.
