[[def: Base Agent]]

** An Agentflow that has begun execution as an Agent but without any additional context, and before any interaction, such as being given an immediate task. A “Base Agent” is a certifiable, reusable Agent instantiation.
