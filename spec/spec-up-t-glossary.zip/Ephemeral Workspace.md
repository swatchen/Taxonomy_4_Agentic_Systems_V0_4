[[def: Ephemeral Workspace]]

A “just-in-time” sandbox workspace created for a single task and destroyed immediately afterward; used to enforce Structural Mortality and to limit persistence in the execution environment.
