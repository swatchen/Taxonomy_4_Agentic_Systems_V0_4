[[def: Embedding Context]]

The containing structures that supply behavior/permissions/meaning to a Component or Framework, explicitly including an Agent Role, Workspace, parent Workflow, or other enclosing structures.
