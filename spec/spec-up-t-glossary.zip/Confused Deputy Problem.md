[[def: Confused Deputy Problem]]

A classic security failure mode where a component with authority is tricked into misusing it (e.g., acting on an attacker-chosen resource). In Appendix B, token capabilities that bind designation+authority are described as eliminating this class of attack.
