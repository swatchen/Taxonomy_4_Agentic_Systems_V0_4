[[def: Unfiltered Agent Workspace]]

A critical failure state where a powerful live agent is instantiated in a workspace with broad actuators and the connecting workflow performs minimal deterministic interpretation/checking, collapsing the triad into a dangerous dyad (agent \+ workspace).
