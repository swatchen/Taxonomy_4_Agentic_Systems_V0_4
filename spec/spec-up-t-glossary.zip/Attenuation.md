[[def: Attenuation]]

In token-based OCAP usage, “the art of weakening”: deriving an explicitly narrower capability token (e.g., reduced permissions or scope) from a more powerful one, so that delegated or remote execution cannot exceed the intended authority bounds.
