[[def: Framework]]

A recipe or architecture for composing heterogeneous Components into a larger system, describing which Components are used, how they connect, what data/capabilities flow between them, and which Workflows and Agent Roles they serve.
