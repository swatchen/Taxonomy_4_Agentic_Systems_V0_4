[[def: Generation-only behavior]]

The architectural constraint that an Agent Workflow (Agentflow) (and therefore an Agent (Live)) is output-only: it can generate media but cannot execute actions by directly invoking Workspace actuators.
