[[def: Cross-Workspace Coordination]]

The explicit, governed interaction between two or more Workspaces, achieved through defined interfaces such as remote Workflow invocation, message passing, or shared registries. Cross-workspace coordination requires explicit trust establishment and never implies implicit authority transfer.
