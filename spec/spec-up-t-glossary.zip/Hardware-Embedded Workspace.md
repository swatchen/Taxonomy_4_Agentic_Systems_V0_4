[[def: Hardware-Embedded Workspace]]

A state where a Live Agent is tightly coupled to specific physical sensors and actuators, such as an autonomous vehicle controller. Certification for this state must cover the entire hardware-software integration due to kinetic risks.
