[[def: Compliance Checker]]

A compiled-in module that vets outputs (or Workflow interpretations) to detect unsafe or adversarial content/requests before they can propagate toward action, or raise alarms soon after. Used as a mitigation in adversarial/failure states.
