[[def: Governance Standards]]

System-wide security/governance rules that become “intractable” to apply when architectural primitives are inconsistently defined across frameworks; T4AS aims to provide a stable vocabulary as a prerequisite.
