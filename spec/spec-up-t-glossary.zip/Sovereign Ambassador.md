[[def: Sovereign Ambassador]]

The function of the public-facing Digital Twin Role: negotiating and representing the principal externally while remaining constrained to curated/aspirational data.
