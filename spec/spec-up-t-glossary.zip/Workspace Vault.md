[[def: Workspace Vault]]

A secure hardware substrate (HSM or TEE) within a Workspace that protects post-quantum identity keys from the Live Agent’s memory, preventing exfiltration even if the agent's generative state is compromised.
