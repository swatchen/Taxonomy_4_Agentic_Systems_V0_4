[[def: Workflow Lifecycle]]

The canonical progression of a Workflow through three states: Workflow (Pre-Execution) (the declarative plan/code), Workload (Executing State) (running/paused instance with live execution state), and Workload Execution Record (Post-Execution) (immutable record of the completed run).
