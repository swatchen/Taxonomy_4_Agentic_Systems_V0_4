[[def: Side Effect]]

Any externally visible or state-mutating action (e.g., writing files, calling APIs, updating data, interacting with users) that, in T4AS, is permitted only through Workspace actuators and must be recorded into Workload Execution Records.
