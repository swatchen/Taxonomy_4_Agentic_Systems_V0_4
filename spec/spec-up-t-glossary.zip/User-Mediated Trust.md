[[def: User-Mediated Trust]]

A trust condition where safety partially relies on the user observing/approving an agent’s actions (e.g., watching a UI-embedded agent “drive” the interface), rather than solely on enforced capability boundaries.
