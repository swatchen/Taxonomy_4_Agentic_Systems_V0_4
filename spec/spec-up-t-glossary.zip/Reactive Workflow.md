[[def: Reactive Workflow]]

A Workflow triggered by events rather than direct user or system calls, responding to Workspace changes/external stimuli/scheduled triggers, and potentially instantiating Agents (Live) or other Workloads as part of handling an event.
