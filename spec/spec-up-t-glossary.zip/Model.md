[[def: Model]]

A “foundational, often opaque computational block” and “probabilistic engine” that generates multi-media outputs from inputs; in its stored form it is inert parameters, and only becomes part of a Live Agent when a Workflow injects context into a Loaded Model for a specific task.
