[[def: Ghost State]]

The archival state of a Workload Execution Record: no longer a live process, but an immutable historical trace of agency stored in the Agent Role and used as memory input for future instantiations.
