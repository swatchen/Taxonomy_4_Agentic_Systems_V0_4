[[def: Embeddedness]]

The degree to which a Component or Framework derives its behavior, permissions, or meaning from the context that contains it—its Agent Role, Workspace, parent Workflow, or other enclosing structures, i.e., the degree it must be embedded in context to function properly. Embeddedness shapes certification scope (global vs contextual).
