[[def: Supervisor Agent]]

** same as Meta-Agent
