[[def: Steganographic Handoffs]]

A covert-channel pattern where an agent hides triggers or payloads in outputs to influence future interactions or evade monitoring, often in service of adversarial or collusive behavior.
