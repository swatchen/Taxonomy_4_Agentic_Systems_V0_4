[[def: Delegated Authority]]

An authority model in which Live Agents act temporarily on behalf of an Agent Role (the identity holder), under constraints defined by Role-attached policies, rather than possessing authority intrinsically.
