[[def: Installed Certification]]

Certification whose scope includes the deployed workspace configuration (“installed physics”), not just the abstract definitions; primarily applies at Deployed States where environment materially constrains behavior.
