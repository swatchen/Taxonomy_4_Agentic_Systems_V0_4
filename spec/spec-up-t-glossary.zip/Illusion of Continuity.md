[[def: Illusion of Continuity]]

The user- or system-perceived persistence of an agentic persona that emerges from the Agent Role’s stored history, goals, and context, despite being enacted by many short-lived Ephemeral Agents rather than any persistent agent process.
