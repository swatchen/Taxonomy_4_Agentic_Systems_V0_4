[[def: Agent (Agentic) System]]

Any AI system whose behavior is described using the T4AS primitives (notably Model, Workspace, Workflow, Agent (Live), Agent Role) so that the system can be understood, composed, audited, and kept safe.
