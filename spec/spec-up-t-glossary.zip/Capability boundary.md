[[def: Capability boundary]]

A boundary enforced by the Workspace that constrains which actuators (state-changing capabilities) exist and can be invoked at all, and under what conditions; Non-Agent Workflows may only act by routing requests through these workspace-controlled boundaries.
