[[def: Generated Workflow]]

A Workflow definition created dynamically by another Workflow at runtime and then executed as a Workload. Generated Workflows are typically highly embedded, short-lived, and tightly coupled to their generating context, imperfectly inheriting trust from that context rather than carrying independent certification.
