[[def: Ecosystem Lock-in]]

A consequence of fragmented and incompatible agent framework semantics (“Tower of Babel”), reducing interoperability and making universal governance difficult.
