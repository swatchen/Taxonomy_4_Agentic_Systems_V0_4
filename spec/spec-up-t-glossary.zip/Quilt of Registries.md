[[def: Quilt of Registries]]

A decentralized, federated network of many smaller registries (e.g., NANDA) used to locate Workspaces, Roles, and Agentflows across administrative domains without a centralized bottleneck.
