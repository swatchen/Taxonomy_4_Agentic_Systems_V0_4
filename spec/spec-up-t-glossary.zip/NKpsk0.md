[[def: NKpsk0]]

A Noise Protocol configuration adapted for hybrid cryptography where the caller authenticates the target Workspace using its static hybrid public key, and the OCAP token itself serves as the Pre-Shared Key (psk0). This enables Zero-Round-Trip (0-RTT) Authorization, where invalid requests are rejected at the connection layer.
