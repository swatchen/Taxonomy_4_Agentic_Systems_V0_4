[[def: Cryptographic Trust Network]]

A distributed trust fabric formed by DIDs, Verifiable Credentials, registries (e.g., NANDA Quilt), and cryptographic handshakes, enabling Workspaces and Workflows to perform automated, verifiable trust decisions about remote Agentflows, Roles, and Workspaces before granting capabilities.
