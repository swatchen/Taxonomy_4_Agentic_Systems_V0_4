[[def: Symmetric Macaroon]]

A high-performance capability token signed with HMAC-SHA512 using keys derived from a secure hybrid session. These tokens are tiny (\<1KB) and efficient to verify in the microsecond range, avoiding the computational latency of lattice-based signatures.
