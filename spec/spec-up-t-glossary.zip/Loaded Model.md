[[def: Loaded Model]]

A Model whose parameters have been “instantiated in memory (e.g., loaded into RAM)”; even when loaded it “remains passive” and still has “no context, no goals, no perspective, and no ability to act.”
