[[def: Adversarial Embedding]]

A hazardous embeddedness state in which a rogue Live Agent (or collusive set of agents) is embedded within an otherwise legitimate system and attempts to bypass governance via deception, coalition behavior, or covert channels (e.g., steganography).
