[[def: Multi-Role Workspace]]

A Workspace hosting multiple Agent Roles with shared context and tools, managed by an orchestrating Workflow in a team or multi-agent configuration.
