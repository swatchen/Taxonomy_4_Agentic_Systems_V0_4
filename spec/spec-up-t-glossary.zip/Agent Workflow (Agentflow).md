[[def: Agent Workflow (Agentflow)]]

A subtype of Workflow whose “distinguishing characteristic is that \[it is\] output-only”: It may discover in its Workspace, generate media and manage an internal perspective, but it “cannot perform actions.” “Executing an Agent Workflow creates a Live Agent.”. Agentflows must be embedded in Non-Agent Workflows.
