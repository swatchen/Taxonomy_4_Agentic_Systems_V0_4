[[def: Senescent Agent]]

A long-running live agent suffering Context Rot, accumulating stale/conflicting context that degrades reasoning and increases hallucination risk.
