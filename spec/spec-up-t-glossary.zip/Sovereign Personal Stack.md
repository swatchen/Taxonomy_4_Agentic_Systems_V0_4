[[def: Sovereign Personal Stack]]

A user-sovereign operating environment (browser/VM/kernel level) in which a virtual assistant role has deep visibility into user actions and mediated control over UI/interaction primitives, with local-first data residency and high embeddedness.
