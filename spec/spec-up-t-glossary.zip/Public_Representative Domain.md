[[def: Public/Representative Domain]]

The network-facing domain/role where a Digital Twin operates as Sovereign Ambassador, trained on Curated Data and Professed Preferences, and responsible for negotiation and vetting without direct access to the Secret Domain.
