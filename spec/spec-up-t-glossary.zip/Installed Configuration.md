[[def: Installed Configuration]]

A loaded configuration that has been bound to a specific runtime environment, hardware stack, and policy regime for a particular user or group. This is the highest state of embeddedness, where trust guarantees must consider the actual operational context.
