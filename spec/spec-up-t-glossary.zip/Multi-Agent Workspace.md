[[def: Multi-Agent Workspace]]

A Workspace hosting multiple Agent Roles and many concurrent Agents (Live), coordinated by Workflows.
