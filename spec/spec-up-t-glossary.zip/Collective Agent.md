[[def: Collective Agent]]

An agentic configuration whose effective “agency” arises from many simple units working in coordination, where state is distributed across the population rather than localized to a single agent instance.
