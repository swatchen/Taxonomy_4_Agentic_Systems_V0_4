[[def: Simulated Workspace]]

A workspace embedding state providing a high-fidelity virtual environment used as a training ground; trustworthiness is inferred from performance within the simulation subject to simulation fidelity.
