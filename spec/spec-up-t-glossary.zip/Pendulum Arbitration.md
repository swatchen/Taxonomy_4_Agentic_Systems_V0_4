[[def: Pendulum Arbitration]]

A dispute-resolution mechanism referenced as part of negotiated connectivity in Digital Twin society, used to moderate post-agreement compliance and enforce spirit-of-agreement norms. Arbiters cannot concoct resolutions, but must select 1 of the presented proposals, incentivizing moderate ones.
