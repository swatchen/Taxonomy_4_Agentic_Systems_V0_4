[[def: Immunity to Confused Deputy]]

A security property claimed for capability-token systems where authority cannot be tricked into operating on attacker-selected resources without possession of the corresponding token that binds designation and permission.
