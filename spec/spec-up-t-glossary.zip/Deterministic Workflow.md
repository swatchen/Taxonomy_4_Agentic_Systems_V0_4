[[def: Deterministic Workflow]]

A Workflow that “contain\[s\] no generative components” and is “fully predictable”: given the same inputs it always produces the same outputs; commonly used as interpreter/validator/evaluator/action-executor logic inside a Workspace.
