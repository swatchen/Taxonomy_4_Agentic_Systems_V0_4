[[def: Chain of Custody]]

The unbroken, auditable linkage from plan → execution → record, enabling an auditor to trace outputs and actions back through intermediate state changes to originating definitions and constraints.
