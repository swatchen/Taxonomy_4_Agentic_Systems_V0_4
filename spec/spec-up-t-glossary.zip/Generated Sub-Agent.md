[[def: Generated Sub-Agent]]

A Live Agent instantiated from a Generated Agent Workflow rather than from a stable, pre-defined Agent Workflow. Its structure, constraints, and behavior are inherited from the generating Workflow’s context rather than from an independently certified definition.
