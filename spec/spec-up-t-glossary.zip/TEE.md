[[def: TEE]]

Trusted Execution Environment: a hardware isolation substrate used for secure enclave embedding of agentic systems, enabling confidentiality of execution state and supporting remote attestation.
