[[def: Indirect Prompt Injection]]

A threat class named here as an “emergent property” of ill-defined, dangerously coupled systems: untrusted content influences the agent’s generated media such that downstream orchestration may be manipulated if interpretation/validation is weak.
