[[def: Privacy–Capability Dilemma]]

The design tension that increased capability often requires broad data access, which conflicts with privacy; addressed here via Segregated Domain separating secret/private and public/representative Roles.
