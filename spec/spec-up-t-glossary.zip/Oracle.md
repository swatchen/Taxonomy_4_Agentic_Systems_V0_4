[[def: Oracle]]

The role constraint placed on a Live Agent in T4AS: It is confined to generating plans/requests (media) and is incapable of acting. This is the term historically used in AI Safety.
