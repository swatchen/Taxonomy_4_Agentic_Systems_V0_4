[[def: Called Agent]]

A Live Agent instantiated from a pre-existing, stable Agent Workflow and invoked via a known interface, rather than dynamically authored at runtime. Called Agents are typically independently versioned and may inherit certification from their underlying Agent Workflow.
