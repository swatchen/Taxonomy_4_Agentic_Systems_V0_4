[[def: Multi-Agent System]]

A system composed of multiple Agents (Live) interacting indirectly via Workflows, possibly instantiated from different Agent Workflows, serving different Agent Roles, and operating concurrently. Direct agent-to-agent communication is disallowed; mediation preserves auditability.
