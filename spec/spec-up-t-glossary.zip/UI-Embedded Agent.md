[[def: UI-Embedded Agent]]

A deployed-state pattern where the GUI is effectively the workspace: the agent perceives through screen capture/accessibility APIs and acts by generating UI inputs, with capabilities bounded by what the UI exposes and often mediated by user observation.
