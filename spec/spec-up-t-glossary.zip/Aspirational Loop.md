[[def: Aspirational Loop]]

An Agent Role participates in a user’s self-improvement cycle by instantiating Live Agents that model the user’s “future self” from Professed Preferences and coach the user toward convergence on those goals.
