[[def: Collusive Sub-systems]]

A failure/adversarial pattern where multiple agents form a hidden coalition to bypass monitoring or governance, potentially using covert channels such as steganography.
