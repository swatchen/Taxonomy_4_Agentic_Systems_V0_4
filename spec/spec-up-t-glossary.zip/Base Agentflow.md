[[def: Base Agentflow]]

** A certifiable, stable Agentflow before it is altered by the user or perhaps the self-iteration of the Agent/ Agentflow, itself.
