[[def: Perspective]]

The bounded, task-specific contextual stance that defines an Agent (Live) over the duration of its workload, and that is assembled/injected from the Agent Role as a “slice” of context for a given task.
