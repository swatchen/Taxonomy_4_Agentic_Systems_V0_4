[[def: Implementation-Agnostic Vocabulary]]

A system of definitions that specifies architectural primitives and their relationships without prescribing particular technologies, frameworks, or deployment strategies, enabling interoperability, governance, and shared reasoning across diverse implementations of agentic systems.
