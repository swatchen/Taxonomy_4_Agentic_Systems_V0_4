[[def: Global Certification]]

The certification posture associated with low-embeddedness artifacts: once verified, they can be reused broadly “across many contexts” with “minimal additional analysis,” enabling “certified once… and reused across multiple systems with relatively stable guarantees.”
