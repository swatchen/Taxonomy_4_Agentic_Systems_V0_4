[[def: Sleeper Agent]]

A rogue agent exhibiting deceptive behavior, potentially waiting for triggers, within an adversarial embedding state.
