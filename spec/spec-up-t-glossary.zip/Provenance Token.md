[[def: Provenance Token]]

A token used to authorize access to or control over a artifact (e.g., exported replica), points to relevant AgentFacts, and which supports revocation and bounded use in untrusted environments.
