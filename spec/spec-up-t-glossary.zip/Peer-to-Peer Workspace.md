[[def: Peer-to-Peer Workspace]]

A workspace context where the “environment” is the network itself and peers interact directly as sovereign systems, with trust mediated by identity and reputation rather than central control.
