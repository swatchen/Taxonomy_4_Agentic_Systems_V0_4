[[def: Sub-Workspace]]

A distinct bounded region of a Workspace used as an implementation structure; in particular, an Agent Role should be implemented as a distinct sub-workspace containing the Role’s data, Workflows, and history, with explicit boundaries around access to external systems and permitted interactions.
