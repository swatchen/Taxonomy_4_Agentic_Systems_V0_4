[[def: Core Invariant]]

One of the three stated invariants by which the Architectural (Safety) Triad yields security and auditability: separation of generation from execution; deterministic/reviewable interpretation; and mediation \+ recording of all side effects in the Workspace.
