[[def: Stateful Migration]]

A mobility mechanism where an agent/workload carries role context (“mind”) by serializing as a paused workload/workflow state to move across workspaces.
