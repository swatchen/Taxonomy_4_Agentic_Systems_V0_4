[[def: Spectrum of Embeddedness]]

A classification dimension describing how strongly an artifact (component/agentflow/live agent/workspace configuration) depends upon and is constrained by its embedding context—including role data, workspace actuators, hardware properties, and societal topology—thereby shaping what can be certified and how portable it is.
