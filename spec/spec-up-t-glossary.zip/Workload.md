[[def: Workload]]

“A running or paused instance of a Workflow,” holding live execution state (current step, intermediate data, references to Agents/actuators called, temporary contexts/variables).
