[[def: Access Control]]

A governance and enforcement function (implemented primarily by the Workspace and its deterministic Non-Agent Workflows) that defines which capabilities (actuators, data, cross-workspace channels) may be exercised by which Workloads, on behalf of which Agent Roles, under which policies and proofs. (See: Workspace, Actuator, Non-Agent Workflow, Agent Role.)
