[[def: Process-Oriented Workflow]]

An explicit Orchestrating Workflow that governs team behavior and coordination among specialized agents, preventing reliance on emergent, non-auditable coordination dynamics.
