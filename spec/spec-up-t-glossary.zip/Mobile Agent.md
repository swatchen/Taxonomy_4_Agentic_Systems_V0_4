[[def: Mobile Agent]]

An agent/workload designed to migrate between host workspaces, carrying context/state via paused/serialized representations, with trust requiring re-evaluation upon arrival.
