[[def: Temporary Economic Alliance]]

An ad-hoc working group formed by sovereign agent roles for an immediate need and dissolved on completion, governed by reputation and negotiated terms rather than permanent institutional control.
