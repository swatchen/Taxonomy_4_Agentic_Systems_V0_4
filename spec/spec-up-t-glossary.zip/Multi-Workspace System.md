[[def: Multi-Workspace System]]

A system consisting of multiple Workspaces, each with independent actuators, policies, certification regimes, and security boundaries, interacting only through explicit, auditable interfaces.
