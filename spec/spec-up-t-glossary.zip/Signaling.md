[[def: Signaling]]

A required, externally visible and cryptographically supported indicator of certain high-impact state changes (e.g., human-in-the-loop avatar possession) so others can distinguish human control from agent control.
