[[def: Avatar Possession]]

A temporary state—typically in a Simulated Workspace—in which the human owner takes direct, real-time control of an agent’s avatar; the Live Agent suppresses generative behavior and acts as a puppet for human input.
